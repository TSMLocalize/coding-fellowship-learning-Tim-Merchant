((d) => {

    let square = document.getElementById('border');

    square.style.borderColor = "red";

})(document)