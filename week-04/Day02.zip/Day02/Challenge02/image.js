((d) => {

    let image = document.getElementById('image');
    
    let height = image.offsetHeight * 2;
    let width = image.offsetWidth * 2;
    
    image.style.height = height + "px";
    image.style.width = width + "px";

})(document)